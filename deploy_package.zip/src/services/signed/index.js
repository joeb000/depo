

export const isProfileSigned = ({ required, roles = User.roles } = {}) => (req, res, next) => {

}